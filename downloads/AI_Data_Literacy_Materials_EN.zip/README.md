# AI and Data Literacy: English teaching materials

Start with [the English edition](en/README.md). For GitHub support, use [GitHub Hands-on Practice](en/github/README.md) and [the student self-check](en/handouts/github_self_check.md). The supplement has a cover, 15 action steps, and two self-check pages. The 16 English course decks are listed below. PDFs contain no notes.
