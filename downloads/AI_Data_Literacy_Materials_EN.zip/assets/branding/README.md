# Author attribution

The logo identifies Takahiro Tsuchiya. See [the material license](../../LICENSE.md).
