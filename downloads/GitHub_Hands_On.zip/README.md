# GitHub hands-on clinic

Start with [Japanese practice](handouts/github_hands_on.md) or [English practice](en/handouts/github_hands_on.md). See [the videos](videos/github/README.md). Instructors: [Japanese teaching plan](instructor/github_clinic.md) / [English teaching plan](en/docs/github_clinic.md). Open each MP4 in a video player. Pause and perform each action in your own Private repository.
