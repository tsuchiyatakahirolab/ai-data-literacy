# GitHub操作補習教材 / GitHub Hands-on Practice

[日本語の教材案内](github/README.md) / [English entry](en/github/README.md)

1. 実習手順を読み、1操作ずつ自分の保存先で実習します。Perform one action at a time in your own repository.
2. 表紙付きスライド・ノートなしPDF・動画を使い、できた目印を確認します。Use the covered slides, PDF, and videos to check each cue.
3. [日本語の自己確認01〜08](handouts/github_self_check.md) / [English self-check 01–08](en/handouts/github_self_check.md)で、画面を順番に開いて確かめます。Open the screens in order before marking them.

日英各18枚（表紙1、操作15、自己確認2）。説明動画3本ずつを含みます。Each edition has 18 pages and three videos. Keep existing repositories and submissions; ask for help before repeating uncertain form submissions.

動画はMP4を標準のプレーヤーで開きます。Open MP4 files in a standard video player. Missing optional course material links open the public GitHub course. Retain author attribution and the material license.
